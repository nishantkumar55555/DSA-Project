import java.util.ArrayList;
import java.io.*;

public class StudentManager {
    private ArrayList<Student> students = new ArrayList<>();
    private final String FILE_NAME = "students.txt";

    public StudentManager() {
        loadStudents();
    }

    public boolean addStudent(String id, String name, String course,
                            String semester, String phone, String email) {
        if (searchById(id) != null) {
            System.out.println("Student ID already exists!");
            return false;
        }
        Student student = new Student(id, name, course, semester, phone, email);
        students.add(student);
        saveStudents();
        System.out.println("Student added successfully!");
        return true;
    }

    public void displayStudents() {
        if (students.isEmpty()) {
            System.out.println("No student records found.");
            return;
        }
        System.out.println("\\n===== STUDENT RECORDS =====");
        for (Student student : students) {
            System.out.println(student);
        }
    }

    public Student searchById(String id) {
        for (Student student : students) {
            if (student.getStudentId().equalsIgnoreCase(id)) {
                return student;
            }
        }
        return null;
    }

    public void searchStudent(String id) {
        Student student = searchById(id);
        if (student != null) {
            System.out.println("\\nStudent Found:");
            System.out.println(student);
        } else {
            System.out.println("Student record not found.");
        }
    }

    public void updateStudent(String id, String name, String course,
                             String semester, String phone, String email) {
        Student student = searchById(id);
        if (student == null) {
            System.out.println("Student not found.");
            return;
        }
        student.setName(name);
        student.setCourse(course);
        student.setSemester(semester);
        student.setPhone(phone);
        student.setEmail(email);
        saveStudents();
        System.out.println("Student updated successfully!");
    }

    public void deleteStudent(String id) {
        Student student = searchById(id);
        if (student == null) {
            System.out.println("Student not found.");
            return;
        }
        students.remove(student);
        saveStudents();
        System.out.println("Student deleted successfully!");
    }

    public void saveStudents() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (Student student : students) {
                writer.write(student.getStudentId() + "|" + student.getName() + "|"
                    + student.getCourse() + "|" + student.getSemester() + "|"
                    + student.getPhone() + "|" + student.getEmail());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving student records.");
        }
    }

    public void loadStudents() {
        File file = new File(FILE_NAME);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split("\\\\|", -1);
                if (data.length == 6) {
                    students.add(new Student(data[0], data[1], data[2],
                        data[3], data[4], data[5]));
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading student records.");
        }
    }
}
