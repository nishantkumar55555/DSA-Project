public class Student {
    private String studentId;
    private String name;
    private String course;
    private String semester;
    private String phone;
    private String email;

    public Student(String studentId, String name, String course,
                  String semester, String phone, String email) {
        this.studentId = studentId;
        this.name = name;
        this.course = course;
        this.semester = semester;
        this.phone = phone;
        this.email = email;
    }

    public String getStudentId() { return studentId; }
    public String getName() { return name; }
    public String getCourse() { return course; }
    public String getSemester() { return semester; }
    public String getPhone() { return phone; }
    public String getEmail() { return email; }

    public void setName(String name) { this.name = name; }
    public void setCourse(String course) { this.course = course; }
    public void setSemester(String semester) { this.semester = semester; }
    public void setPhone(String phone) { this.phone = phone; }
    public void setEmail(String email) { this.email = email; }

    @Override
    public String toString() {
        return "ID: " + studentId + " | Name: " + name
            + " | Course: " + course + " | Semester: " + semester
            + " | Phone: " + phone + " | Email: " + email;
    }
}
