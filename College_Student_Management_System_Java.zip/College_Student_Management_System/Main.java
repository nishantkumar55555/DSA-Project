import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StudentManager manager = new StudentManager();
        int choice;

        do {
            System.out.println("\\n===== COLLEGE STUDENT MANAGEMENT SYSTEM =====");
            System.out.println("1. Add Student");
            System.out.println("2. Display All Students");
            System.out.println("3. Search Student by ID");
            System.out.println("4. Update Student");
            System.out.println("5. Delete Student");
            System.out.println("6. Exit");
            System.out.println("------------------------------------------");
            System.out.print("Enter your choice: ");

            while (!sc.hasNextInt()) {
                System.out.println("Please enter a valid number.");
                sc.next();
                System.out.print("Enter your choice: ");
            }
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Student ID: ");
                    String id = sc.nextLine();
                    System.out.print("Name: ");
                    String name = sc.nextLine();
                    System.out.print("Course: ");
                    String course = sc.nextLine();
                    System.out.print("Semester: ");
                    String semester = sc.nextLine();
                    System.out.print("Phone: ");
                    String phone = sc.nextLine();
                    System.out.print("Email: ");
                    String email = sc.nextLine();

                    if (id.trim().isEmpty() || name.trim().isEmpty()
                        || course.trim().isEmpty() || semester.trim().isEmpty()
                        || phone.trim().isEmpty() || email.trim().isEmpty()) {
                        System.out.println("All fields are required!");
                    } else {
                        manager.addStudent(id, name, course, semester, phone, email);
                    }
                    break;

                case 2:
                    manager.displayStudents();
                    break;

                case 3:
                    System.out.print("Enter Student ID: ");
                    manager.searchStudent(sc.nextLine());
                    break;

                case 4:
                    System.out.print("Enter Student ID to update: ");
                    String updateId = sc.nextLine();
                    if (manager.searchById(updateId) == null) {
                        System.out.println("Student not found.");
                        break;
                    }
                    System.out.print("New Name: ");
                    String newName = sc.nextLine();
                    System.out.print("New Course: ");
                    String newCourse = sc.nextLine();
                    System.out.print("New Semester: ");
                    String newSemester = sc.nextLine();
                    System.out.print("New Phone: ");
                    String newPhone = sc.nextLine();
                    System.out.print("New Email: ");
                    String newEmail = sc.nextLine();
                    manager.updateStudent(updateId, newName, newCourse,
                        newSemester, newPhone, newEmail);
                    break;

                case 5:
                    System.out.print("Enter Student ID to delete: ");
                    manager.deleteStudent(sc.nextLine());
                    break;

                case 6:
                    manager.saveStudents();
                    System.out.println("Data saved successfully.");
                    System.out.println("Exiting program...");
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }
        } while (choice != 6);

        sc.close();
    }
}
