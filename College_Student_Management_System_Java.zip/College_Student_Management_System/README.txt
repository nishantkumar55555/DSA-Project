COLLEGE STUDENT MANAGEMENT SYSTEM - JAVA

Files:
- Student.java
- StudentManager.java
- Main.java

Requirements:
- Java JDK 8 or newer
- Command Prompt / Terminal or VS Code

Run:
1. Extract the ZIP.
2. Open the extracted folder in Terminal/CMD.
3. Compile:
   javac Student.java StudentManager.java Main.java
4. Run:
   java Main

The program creates students.txt automatically in the same folder to save records.

Menu:
1. Add Student
2. Display All Students
3. Search Student by ID
4. Update Student
5. Delete Student
6. Exit
